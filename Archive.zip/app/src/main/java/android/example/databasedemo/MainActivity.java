package android.example.databasedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    TextView tv = findViewById(R.id.textview);

        //this method creates a new or opens an existing database
        SQLiteDatabase myDataBase = this.openOrCreateDatabase("Users", MODE_PRIVATE, null);

        //create the table with the required columns
        myDataBase.execSQL("CREATE TABLE IF NOT EXISTS users (name VARCHAR, age INT(3))");

        //insert these values into the database
        myDataBase.execSQL("INSERT INTO users (name, age) VALUES ('Peter', 23)");
        myDataBase.execSQL("INSERT INTO users (name, age) VALUES ('Helen', 35)");

        //create a database query using the Cursor
        Cursor c = myDataBase.rawQuery("SELECT * FROM users", null);


        //now try to get info from the database,

        try {

            //first create a TextView and set the initial content.
            tv.setText("These are the number of items: " + c + "\n\n");

            while (c.moveToNext()) {

            int nameIndex = c.getInt(c.getColumnIndex(myDataBase.get))
            int ageIndex = c.getColumnIndex("age");






       /*
        //we use a while loop to move through the table
        while (c != null) {// && x < items.size()-1) {


            //   items.add(Integer.parseInt(c.getString(nameIndex)), c.getInt(ageIndex));

            //   items.add(c.getInt(nameIndex));


            c.moveToNext();

        */

       myDataBase.close();
       this.finish();


        }
    } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
